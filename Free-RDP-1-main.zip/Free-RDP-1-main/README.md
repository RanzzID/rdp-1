![Windows](http://sekai.cloud/0:/image_2022-05-30_12-43-13.png)
![Specification](http://sekai.cloud/0:/image_2022-05-30_12-44-01.png)
# 1 Hour Free Windows RDP [NGROK](https://ngrok.com/)

# Tutorials :

+ Fork this Repo.

+ Visit [NGROK](https://dashboard.ngrok.com). Register/Login

+ Inside the forked Repo, go to :\
   ```Settings > Secrets > Actions > New repository secret.```

+ Fill in \
Name : NGROK_AUTH_TOKEN \
Value : Visit [GET NGROK AUTH TOKEN](https://dashboard.ngrok.com/auth/your-authtoken). Copy and Paste in Value.

+ Press Add secret.

+ Go To :\
```Action > Select RDP > Run workflow > Click Run workflow.```

+ Refresh the Web/page and go to :\
```RDP > Build.```

+ *Wait 1-5 minutes*

+ Press the down arrow button that says (Connect RDP) to get IP, User and Password.

+ If RDP Close Connection : \
```Action > Select RDP > Click build > Re-run jobs > Re-run all jobs.```
